document.getElementById("btnDisplaySequence").onclick = function() {myFunction()};

function myFunction() {
    let choice = document.getElementsByAttribute("value").value;
    let results;


  /**  

    if (choice == odd) {

        for (let i = 1; i < 20; i++) {
            if(i % 2 != 0) {
                results = i + ", ";
            }
        }
    } else if (choice == even) {

        for (let i = 2; i < 20; i++) {
            if(i % 2 == 0) {
                results = i + ", ";
            }
        }
    } else if (choice == fibonacci) {
        
        let num1;
        let num2;
        let next;
        let fibonacciSequenceText;

    } else {
        alert("Invalid selection, please try again!");
    }
    
    document.getElementById("seqResults").innerHTML = value;
}
 */