/*
============================================
; Title:  Green-exercise2.js
; Author: Tierre Green
; Date:  17 January 2021
; Description: Displays message to the console window
;===========================================
*/

/**
============================================
; Title:  JavaScript Where To
; Author: w3schools.com
; Date:  17 January 2021
; Modified By: Tierre Green
; Description: calling js statement by using document.getElementById
;===========================================
 */

 /**
============================================
; Title:  JavaScript Popup Boxes
; Author: w3schools.com
; Date:  17 January 2021
; Modified By: Tierre Green
; Description: function for a popup box when pressing a button.
;===========================================
 */


/**
 *script binding the world statement to innerHTML of txtMyWorld
 */

document.getElementById("txtMyWorld").innerHTML = "You are now in Green's world";

/**
 * function for button class item and creating alert window
 * for the class I am in.
 */

function myFunction() {
    alert("WEB 231 - Enterprise JavaScript I");
}



